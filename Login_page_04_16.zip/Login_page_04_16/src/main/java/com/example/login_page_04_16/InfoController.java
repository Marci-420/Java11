package com.example.login_page_04_16;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class InfoController {
    @FXML
    private Label l1, l2;
}



