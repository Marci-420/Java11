/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package meszaros_marcell_zsolt;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author user3
 */
public class Meszaros_Marcell_Zsolt {

    
    public static boolean email(){
         
        while (!("@" in email ))
    }   
    
   
            
       
    
    
        
      
    
    public static void main(String[] args) {
        //Kérje be a program a felhasználótól az email címét addig, amíg formailag nem megfelelő címet ad meg
        Scanner igaze = new Scanner(System.in);
        System.out.println("Adja meg az e-mail címét: ");
        int email = igaze.nextInt();
        
        //Hozz létre egy 5 elemű tömböt vagy ArrayList-et. Töltsd fel random egész szám adatokkal 10 és 20 között
        int[] lista = new int[5];
        int Randomsz = (int) (Math.random() * 5) +1;
               System.out.println(Randomsz);
        
        //hány olyan szám van a tömbben vagy listában, melyet egy tőle nagyobb szám követ?
        
        
        //Vizsgáld meg, hogy a tömb elemei növekvő sorrendben állnak-e
        
       
    }
    
    
    
}
